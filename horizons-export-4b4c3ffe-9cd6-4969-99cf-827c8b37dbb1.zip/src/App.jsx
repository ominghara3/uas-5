
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart, Plus, Minus, Star, Leaf, Award, Truck, Phone, Mail, MapPin, Menu, X, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { Toaster } from '@/components/ui/toaster';

function App() {
  const [cart, setCart] = useState([]);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('semua');

  // Load cart from localStorage
  useEffect(() => {
    const savedCart = localStorage.getItem('tokoPanduCart');
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }
  }, []);

  // Save cart to localStorage
  useEffect(() => {
    localStorage.setItem('tokoPanduCart', JSON.stringify(cart));
  }, [cart]);

  const categories = [
    { id: 'semua', name: 'Semua Produk', icon: '🛒' },
    { id: 'buah', name: 'Buah-buahan', icon: '🍎' },
    { id: 'sayur', name: 'Sayuran', icon: '🥬' },
    { id: 'bumbu', name: 'Bumbu Dapur', icon: '🌶️' },
    { id: 'lainnya', name: 'Lainnya', icon: '🥫' }
  ];

  const products = [
    // Buah-buahan
    { id: 1, name: 'Apel Malang', price: 25000, unit: 'kg', category: 'buah', rating: 4.8, stock: 50, description: 'Apel segar dari Malang, manis dan renyah' },
    { id: 2, name: 'Jeruk Pontianak', price: 20000, unit: 'kg', category: 'buah', rating: 4.7, stock: 30, description: 'Jeruk manis khas Pontianak, kaya vitamin C' },
    { id: 3, name: 'Pisang Cavendish', price: 15000, unit: 'sisir', category: 'buah', rating: 4.9, stock: 25, description: 'Pisang premium, cocok untuk jus dan cemilan' },
    { id: 4, name: 'Mangga Harum Manis', price: 35000, unit: 'kg', category: 'buah', rating: 4.8, stock: 20, description: 'Mangga matang sempurna, harum dan manis' },
    { id: 5, name: 'Anggur Hijau', price: 45000, unit: 'kg', category: 'buah', rating: 4.6, stock: 15, description: 'Anggur segar tanpa biji, rasa manis alami' },
    
    // Sayuran
    { id: 6, name: 'Bayam Segar', price: 8000, unit: 'ikat', category: 'sayur', rating: 4.7, stock: 40, description: 'Bayam organik segar, kaya zat besi' },
    { id: 7, name: 'Kangkung Darat', price: 6000, unit: 'ikat', category: 'sayur', rating: 4.8, stock: 35, description: 'Kangkung segar untuk tumisan yang lezat' },
    { id: 8, name: 'Tomat Merah', price: 12000, unit: 'kg', category: 'sayur', rating: 4.5, stock: 30, description: 'Tomat matang sempurna, cocok untuk masakan' },
    { id: 9, name: 'Wortel Baby', price: 18000, unit: 'kg', category: 'sayur', rating: 4.9, stock: 25, description: 'Wortel muda yang manis dan renyah' },
    { id: 10, name: 'Brokoli Segar', price: 22000, unit: 'kg', category: 'sayur', rating: 4.6, stock: 20, description: 'Brokoli hijau segar, kaya nutrisi' },
    
    // Bumbu Dapur
    { id: 11, name: 'Cabai Merah Keriting', price: 35000, unit: 'kg', category: 'bumbu', rating: 4.7, stock: 15, description: 'Cabai segar dengan tingkat kepedasan sedang' },
    { id: 12, name: 'Bawang Merah', price: 28000, unit: 'kg', category: 'bumbu', rating: 4.8, stock: 40, description: 'Bawang merah berkualitas untuk bumbu masakan' },
    { id: 13, name: 'Bawang Putih', price: 32000, unit: 'kg', category: 'bumbu', rating: 4.9, stock: 35, description: 'Bawang putih segar dengan aroma kuat' },
    { id: 14, name: 'Jahe Merah', price: 25000, unit: 'kg', category: 'bumbu', rating: 4.6, stock: 20, description: 'Jahe merah segar untuk minuman dan masakan' },
    
    // Lainnya
    { id: 15, name: 'Telur Ayam Kampung', price: 45000, unit: 'kg', category: 'lainnya', rating: 4.9, stock: 30, description: 'Telur ayam kampung segar dan bergizi' },
    { id: 16, name: 'Madu Murni', price: 85000, unit: 'botol', category: 'lainnya', rating: 4.8, stock: 10, description: 'Madu murni 100% tanpa campuran' },
    { id: 17, name: 'Tempe Segar', price: 8000, unit: 'papan', category: 'lainnya', rating: 4.7, stock: 25, description: 'Tempe segar buatan lokal yang berkualitas' },
    { id: 18, name: 'Tahu Putih', price: 6000, unit: 'papan', category: 'lainnya', rating: 4.6, stock: 30, description: 'Tahu putih segar untuk berbagai masakan' }
  ];

  const filteredProducts = products.filter(product => {
    const matchesCategory = selectedCategory === 'semua' || product.category === selectedCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const addToCart = (product) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prevCart, { ...product, quantity: 1 }];
    });
    
    toast({
      title: "Ditambahkan ke keranjang! 🛒",
      description: `${product.name} berhasil ditambahkan`,
      duration: 2000,
    });
  };

  const updateQuantity = (id, change) => {
    setCart(prevCart => {
      return prevCart.map(item => {
        if (item.id === id) {
          const newQuantity = item.quantity + change;
          return newQuantity > 0 ? { ...item, quantity: newQuantity } : null;
        }
        return item;
      }).filter(Boolean);
    });
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  };

  const handleCheckout = () => {
    if (cart.length === 0) {
      toast({
        title: "Keranjang kosong! 🛒",
        description: "Silakan tambahkan produk terlebih dahulu",
        duration: 3000,
      });
      return;
    }
    
    toast({
      title: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀",
      duration: 4000,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-green-50">
      <Toaster />
      
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-green-100 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <motion.div 
              className="flex items-center space-x-3"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="w-12 h-12 gradient-bg rounded-full flex items-center justify-center shadow-glow">
                <Leaf className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold gradient-text">Toko Pandu</h1>
                <p className="text-sm text-gray-600">Supplier Buah & Sayur Segar</p>
              </div>
            </motion.div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <a href="#home" className="text-gray-700 hover:text-green-600 transition-colors font-medium">Beranda</a>
              <a href="#products" className="text-gray-700 hover:text-green-600 transition-colors font-medium">Produk</a>
              <a href="#about" className="text-gray-700 hover:text-green-600 transition-colors font-medium">Tentang</a>
              <a href="#contact" className="text-gray-700 hover:text-green-600 transition-colors font-medium">Kontak</a>
            </nav>

            {/* Cart & Mobile Menu */}
            <div className="flex items-center space-x-4">
              <motion.div 
                className="relative"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="relative border-green-200 hover:bg-green-50"
                  onClick={() => toast({
                    title: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀",
                    duration: 4000,
                  })}
                >
                  <ShoppingCart className="w-5 h-5" />
                  {getTotalItems() > 0 && (
                    <motion.span 
                      className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", stiffness: 500 }}
                    >
                      {getTotalItems()}
                    </motion.span>
                  )}
                </Button>
              </motion.div>

              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
            </div>
          </div>

          {/* Mobile Menu */}
          <AnimatePresence>
            {isMenuOpen && (
              <motion.nav
                className="md:hidden mt-4 py-4 border-t border-green-100"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex flex-col space-y-4">
                  <a href="#home" className="text-gray-700 hover:text-green-600 transition-colors font-medium">Beranda</a>
                  <a href="#products" className="text-gray-700 hover:text-green-600 transition-colors font-medium">Produk</a>
                  <a href="#about" className="text-gray-700 hover:text-green-600 transition-colors font-medium">Tentang</a>
                  <a href="#contact" className="text-gray-700 hover:text-green-600 transition-colors font-medium">Kontak</a>
                </div>
              </motion.nav>
            )}
          </AnimatePresence>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="py-20 relative overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
                Buah & Sayur
                <span className="gradient-text block">Segar Setiap Hari</span>
              </h2>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Dapatkan produk segar berkualitas tinggi langsung dari petani lokal. 
                Kami menjamin kesegaran dan kualitas terbaik untuk keluarga Anda.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="gradient-bg hover:shadow-glow transition-all duration-300 text-lg px-8 py-6"
                  onClick={() => document.getElementById('products').scrollIntoView({ behavior: 'smooth' })}
                >
                  Lihat Produk
                </Button>
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="border-green-200 hover:bg-green-50 text-lg px-8 py-6"
                  onClick={() => toast({
                    title: "🚧 Fitur ini belum diimplementasikan—tapi jangan khawatir! Anda bisa memintanya di prompt berikutnya! 🚀",
                    duration: 4000,
                  })}
                >
                  Hubungi Kami
                </Button>
              </div>
            </motion.div>

            <motion.div
              className="relative"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <div className="relative">
                <img  
                  className="w-full h-auto rounded-3xl shadow-2xl animate-float" 
                  alt="Buah dan sayur segar di keranjang"
                 src="https://images.unsplash.com/photo-1641508296397-5fb75bafa4c8" />
                <div className="absolute -top-4 -right-4 bg-yellow-400 text-yellow-900 px-4 py-2 rounded-full font-bold shadow-lg animate-pulse-slow">
                  100% Segar!
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Floating Elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-green-200 rounded-full opacity-20 animate-float"></div>
        <div className="absolute bottom-20 right-10 w-32 h-32 bg-yellow-200 rounded-full opacity-20 animate-float" style={{ animationDelay: '1s' }}></div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Mengapa Pilih Toko Pandu?</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Kami berkomitmen memberikan yang terbaik untuk pelanggan dengan layanan dan produk berkualitas tinggi
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <Leaf className="w-8 h-8" />,
                title: "100% Organik",
                description: "Semua produk kami berasal dari pertanian organik tanpa pestisida berbahaya"
              },
              {
                icon: <Truck className="w-8 h-8" />,
                title: "Pengiriman Cepat",
                description: "Pengiriman same day untuk area Jabodetabek, produk sampai dalam kondisi segar"
              },
              {
                icon: <Award className="w-8 h-8" />,
                title: "Kualitas Terjamin",
                description: "Setiap produk melalui quality control ketat untuk memastikan kesegaran optimal"
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                className="text-center p-8 rounded-2xl bg-gradient-to-br from-green-50 to-white border border-green-100 hover:shadow-lg transition-all duration-300"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
              >
                <div className="w-16 h-16 gradient-bg rounded-full flex items-center justify-center mx-auto mb-4 text-white shadow-glow">
                  {feature.icon}
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h4>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-20 bg-gradient-to-br from-green-50 via-white to-green-50">
        <div className="container mx-auto px-4">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="text-4xl font-bold text-gray-900 mb-4">Produk Segar Kami</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Pilihan lengkap buah, sayur, dan kebutuhan dapur dengan kualitas terbaik
            </p>
          </motion.div>

          {/* Search and Filter */}
          <div className="mb-8 space-y-4">
            <div className="relative max-w-md mx-auto">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Cari produk..."
                className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div className="flex flex-wrap justify-center gap-3">
              {categories.map((category) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  className={`${
                    selectedCategory === category.id 
                      ? "gradient-bg text-white shadow-glow" 
                      : "border-green-200 hover:bg-green-50"
                  } transition-all duration-300`}
                  onClick={() => setSelectedCategory(category.id)}
                >
                  <span className="mr-2">{category.icon}</span>
                  {category.name}
                </Button>
              ))}
            </div>
          </div>

          {/* Products Grid */}
          <motion.div 
            className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
            layout
          >
            <AnimatePresence>
              {filteredProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden border border-gray-100"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                  whileHover={{ y: -5 }}
                  layout
                >
                  <div className="relative">
                    <img  
                      className="w-full h-48 object-cover" 
                      alt={`${product.name} segar berkualitas tinggi`}
                     src="https://images.unsplash.com/photo-1542372508-6925e3f65099" />
                    <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full text-sm font-medium text-gray-700">
                      Stok: {product.stock}
                    </div>
                  </div>

                  <div className="p-6">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-lg font-semibold text-gray-900">{product.name}</h4>
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm text-gray-600">{product.rating}</span>
                      </div>
                    </div>

                    <p className="text-gray-600 text-sm mb-3 line-clamp-2">{product.description}</p>

                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <span className="text-2xl font-bold text-green-600">
                          Rp {product.price.toLocaleString('id-ID')}
                        </span>
                        <span className="text-gray-500 text-sm">/{product.unit}</span>
                      </div>
                    </div>

                    {cart.find(item => item.id === product.id) ? (
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => updateQuantity(product.id, -1)}
                            className="w-8 h-8 p-0 border-green-200 hover:bg-green-50"
                          >
                            <Minus className="w-4 h-4" />
                          </Button>
                          <span className="font-semibold text-lg min-w-[2rem] text-center">
                            {cart.find(item => item.id === product.id)?.quantity || 0}
                          </span>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => updateQuantity(product.id, 1)}
                            className="w-8 h-8 p-0 border-green-200 hover:bg-green-50"
                          >
                            <Plus className="w-4 h-4" />
                          </Button>
                        </div>
                        <span className="text-sm font-medium text-green-600">
                          Rp {((cart.find(item => item.id === product.id)?.quantity || 0) * product.price).toLocaleString('id-ID')}
                        </span>
                      </div>
                    ) : (
                      <Button 
                        className="w-full gradient-bg hover:shadow-glow transition-all duration-300"
                        onClick={() => addToCart(product)}
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Tambah ke Keranjang
                      </Button>
                    )}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>

          {filteredProducts.length === 0 && (
            <motion.div
              className="text-center py-12"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              <div className="text-6xl mb-4">🔍</div>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">Produk tidak ditemukan</h4>
              <p className="text-gray-600">Coba ubah kata kunci pencarian atau kategori</p>
            </motion.div>
          )}
        </div>
      </section>

      {/* Cart Summary */}
      {cart.length > 0 && (
        <motion.div
          className="fixed bottom-6 right-6 bg-white rounded-2xl shadow-2xl p-6 border border-gray-100 max-w-sm z-40"
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h4 className="text-lg font-semibold text-gray-900 mb-4">Ringkasan Keranjang</h4>
          <div className="space-y-2 mb-4 max-h-32 overflow-y-auto">
            {cart.map((item) => (
              <div key={item.id} className="flex justify-between text-sm">
                <span className="text-gray-600">{item.name} x{item.quantity}</span>
                <span className="font-medium">Rp {(item.price * item.quantity).toLocaleString('id-ID')}</span>
              </div>
            ))}
          </div>
          <div className="border-t border-gray-200 pt-3 mb-4">
            <div className="flex justify-between font-semibold text-lg">
              <span>Total:</span>
              <span className="text-green-600">Rp {getTotalPrice().toLocaleString('id-ID')}</span>
            </div>
          </div>
          <Button 
            className="w-full gradient-bg hover:shadow-glow transition-all duration-300"
            onClick={handleCheckout}
          >
            Checkout ({getTotalItems()} item)
          </Button>
        </motion.div>
      )}

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <img  
                className="w-full h-auto rounded-3xl shadow-2xl" 
                alt="Pemilik Toko Pandu di kebun sayur organik"
               src="https://images.unsplash.com/photo-1690002858614-3453f9c83ffd" />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h3 className="text-4xl font-bold text-gray-900 mb-6">Tentang Toko Pandu</h3>
              <p className="text-gray-600 text-lg mb-6 leading-relaxed">
                Toko Pandu telah melayani masyarakat selama lebih dari 10 tahun dengan komitmen 
                menyediakan buah dan sayuran segar berkualitas tinggi. Kami bekerja sama langsung 
                dengan petani lokal untuk memastikan produk yang sampai ke tangan Anda selalu dalam 
                kondisi terbaik.
              </p>
              <p className="text-gray-600 text-lg mb-8 leading-relaxed">
                Dengan pengalaman bertahun-tahun, kami memahami kebutuhan keluarga Indonesia akan 
                makanan sehat dan bergizi. Setiap produk dipilih dengan teliti dan melalui proses 
                quality control yang ketat.
              </p>
              
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="text-center p-4 bg-green-50 rounded-xl">
                  <div className="text-3xl font-bold text-green-600 mb-2">10+</div>
                  <div className="text-gray-600">Tahun Pengalaman</div>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-xl">
                  <div className="text-3xl font-bold text-green-600 mb-2">1000+</div>
                  <div className="text-gray-600">Pelanggan Puas</div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gradient-to-br from-green-50 via-white to-green-50">
        <div className="container mx-auto px-4">
          <motion.div
            className="text-center mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h3 className="text-4xl font-bold text-gray-900 mb-4">Hubungi Kami</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Siap melayani Anda dengan produk segar terbaik. Jangan ragu untuk menghubungi kami!
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {[
              {
                icon: <Phone className="w-6 h-6" />,
                title: "Telepon",
                info: "+62 812-3456-7890",
                description: "Senin - Sabtu, 08:00 - 17:00"
              },
              {
                icon: <Mail className="w-6 h-6" />,
                title: "Email",
                info: "info@tokopandu.com",
                description: "Respon dalam 24 jam"
              },
              {
                icon: <MapPin className="w-6 h-6" />,
                title: "Alamat",
                info: "Jl. Segar Raya No. 123",
                description: "Jakarta Selatan, 12345"
              }
            ].map((contact, index) => (
              <motion.div
                key={index}
                className="text-center p-8 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -5 }}
              >
                <div className="w-16 h-16 gradient-bg rounded-full flex items-center justify-center mx-auto mb-4 text-white shadow-glow">
                  {contact.icon}
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">{contact.title}</h4>
                <p className="text-lg font-medium text-green-600 mb-2">{contact.info}</p>
                <p className="text-gray-600 text-sm">{contact.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 gradient-bg rounded-full flex items-center justify-center">
                  <Leaf className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold">Toko Pandu</span>
              </div>
              <p className="text-gray-400 mb-4">
                Supplier terpercaya untuk buah dan sayuran segar berkualitas tinggi.
              </p>
            </div>

            <div>
              <span className="text-lg font-semibold mb-4 block">Produk</span>
              <ul className="space-y-2 text-gray-400">
                <li>Buah-buahan</li>
                <li>Sayuran</li>
                <li>Bumbu Dapur</li>
                <li>Produk Organik</li>
              </ul>
            </div>

            <div>
              <span className="text-lg font-semibold mb-4 block">Layanan</span>
              <ul className="space-y-2 text-gray-400">
                <li>Pengiriman Same Day</li>
                <li>Konsultasi Nutrisi</li>
                <li>Pemesanan Grosir</li>
                <li>Quality Guarantee</li>
              </ul>
            </div>

            <div>
              <span className="text-lg font-semibold mb-4 block">Jam Operasional</span>
              <div className="space-y-2 text-gray-400">
                <p>Senin - Jumat: 08:00 - 17:00</p>
                <p>Sabtu: 08:00 - 15:00</p>
                <p>Minggu: Tutup</p>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Toko Pandu. Semua hak cipta dilindungi.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
